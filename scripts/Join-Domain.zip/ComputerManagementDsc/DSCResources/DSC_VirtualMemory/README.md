# Description

The resource allows configuration of properties of the paging file on
the local computer.
